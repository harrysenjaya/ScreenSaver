package id.ac.unpar.siamodels.matakuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Teknologi Multimedia", sks = 3)
public class AIF468 extends MataKuliah {

}