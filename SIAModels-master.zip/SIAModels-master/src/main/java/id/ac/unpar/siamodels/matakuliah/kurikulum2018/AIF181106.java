package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.matakuliah.interfaces.HasPraktikum;
import id.ac.unpar.siamodels.matakuliah.interfaces.HasResponsi;


@InfoMataKuliah(nama = "Matriks dan Ruang Vektor", sks = 3)
public class AIF181106 extends MataKuliah implements HasResponsi {

}
