package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

/**
 * @deprecated Mata kuliah tidak dibuka lagi.
 */
@InfoMataKuliah(nama = "Desain & Analisis Algoritma", sks = 3)
public class AIF292 extends MataKuliah {

}
