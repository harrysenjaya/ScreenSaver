package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.matakuliah.interfaces.*;


@InfoMataKuliah(nama = "Komputer dan Masyarakat", sks = 2)
public class AIF184005 extends MataKuliah{

}
