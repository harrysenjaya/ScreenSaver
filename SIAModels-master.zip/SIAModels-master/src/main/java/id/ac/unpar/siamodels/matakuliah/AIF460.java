package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;

@InfoMataKuliah(nama = "Manajemen Pengetahuan", sks = 2)
public class AIF460 extends MataKuliah {

}
