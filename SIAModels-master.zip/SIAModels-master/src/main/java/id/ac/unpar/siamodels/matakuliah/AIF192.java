package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

/**
 * @deprecated Mata kuliah tidak dibuka lagi.
 */
@InfoMataKuliah(nama = "Algoritma & Struktur Data", sks = 3)
public class AIF192 extends MataKuliah {

}