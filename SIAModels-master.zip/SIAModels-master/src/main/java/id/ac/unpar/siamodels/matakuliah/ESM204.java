package id.ac.unpar.siamodels.matakuliah;


import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Manajemen Keuangan I", sks = 3)
public class ESM204 extends MataKuliah {

}