package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Arsitektur dan Organisasi Komputer", sks = 3)
public class AIF132205 extends MataKuliah {

}
