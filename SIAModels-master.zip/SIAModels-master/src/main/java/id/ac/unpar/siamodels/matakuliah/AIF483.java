package id.ac.unpar.siamodels.matakuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Teknik Kompilasi", sks = 2)
public class AIF483 extends MataKuliah {
    
}