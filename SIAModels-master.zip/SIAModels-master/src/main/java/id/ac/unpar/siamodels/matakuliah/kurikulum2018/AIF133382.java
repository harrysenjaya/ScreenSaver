package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Gudang Data dan Penambangan Data", sks = 3)
public class AIF133382 extends MataKuliah {

}
