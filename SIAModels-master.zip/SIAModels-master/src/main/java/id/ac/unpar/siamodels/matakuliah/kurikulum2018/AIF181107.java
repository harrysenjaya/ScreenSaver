package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.matakuliah.interfaces.HasPraktikum;


@InfoMataKuliah(nama = "Matematika Diskret", sks = 3)
public class AIF181107 extends MataKuliah {

}
