package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

/**
 * Mendalami perilaku sehari-hari yang baik dalam bermasyarakat.
 * 
 */
@InfoMataKuliah(nama = "Etika", sks = 2)
public class MKU008 extends MataKuliah{

}
