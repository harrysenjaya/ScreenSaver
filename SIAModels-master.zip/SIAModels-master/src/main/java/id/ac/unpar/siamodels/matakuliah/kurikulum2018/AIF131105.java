package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Pengantar Informatika", sks = 3)
public class AIF131105 extends MataKuliah {

}
