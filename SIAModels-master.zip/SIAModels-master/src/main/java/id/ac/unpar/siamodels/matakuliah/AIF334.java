package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Topik Khusus Sistem Informasi 2", sks = 3)
public class AIF334 extends MataKuliah {

}