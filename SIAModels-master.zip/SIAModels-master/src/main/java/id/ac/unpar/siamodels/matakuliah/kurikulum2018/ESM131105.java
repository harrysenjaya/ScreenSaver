package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Manajemen", sks = 3)
public class ESM131105 extends MataKuliah {

}
