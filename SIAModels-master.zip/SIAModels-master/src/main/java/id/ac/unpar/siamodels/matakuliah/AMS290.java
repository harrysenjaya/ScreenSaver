package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Aljabar & Linear Matriks", sks = 3)
public class AMS290 extends MataKuliah {

}