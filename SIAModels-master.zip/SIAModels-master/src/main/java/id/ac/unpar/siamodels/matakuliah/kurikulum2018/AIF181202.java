package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.matakuliah.interfaces.HasPraktikum;


@InfoMataKuliah(nama = "Arsitektur dan Organisasi Komputer", sks = 4)
public class AIF181202 extends MataKuliah {

}
