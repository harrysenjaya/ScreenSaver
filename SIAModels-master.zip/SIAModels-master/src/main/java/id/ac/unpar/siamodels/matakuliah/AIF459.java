package id.ac.unpar.siamodels.matakuliah;


import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Adaministrasi Basis Data", sks = 3)
public class AIF459 extends MataKuliah {

}