package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Praktika Pemrograman Basis Data", sks = 1)
public class AIF133384 extends MataKuliah {

}
