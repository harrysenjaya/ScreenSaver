package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Kalkulus", sks = 4)
public class AMS131191 extends MataKuliah {

}
