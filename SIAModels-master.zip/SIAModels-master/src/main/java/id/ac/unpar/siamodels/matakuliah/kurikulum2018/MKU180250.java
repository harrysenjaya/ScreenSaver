package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.matakuliah.interfaces.HasPraktikum;


@InfoMataKuliah(nama = "Pendidikan Pancasila", sks = 2)
public class MKU180250 extends MataKuliah {

}
