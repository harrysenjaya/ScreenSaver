package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Akuntansi Keuangan Dasar II", sks = 2)
public class EAA102 extends MataKuliah {

}