package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;

@InfoMataKuliah(nama = "Pengolahan Citra", sks = 3)
public class AIF450 extends MataKuliah {

}
