package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Praktika Interaksi Manusia Komputer", sks = 1)
public class AIF280 extends MataKuliah {

}