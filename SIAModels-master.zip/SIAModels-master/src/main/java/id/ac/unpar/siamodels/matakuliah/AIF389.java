
package id.ac.unpar.siamodels.matakuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Kriptografi", sks = 2)
public class AIF389 extends MataKuliah {

}
