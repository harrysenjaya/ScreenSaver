package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Sistem Perusahaan Bersakala Besar", sks = 2)
public class AIF134464 extends MataKuliah {

}
