package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

/**
 * @deprecated Mata kuliah tidak dibuka lagi.
 */
@InfoMataKuliah(nama = "Pemrograman Berorientasi Objek", sks = 3)
public class AIF191 extends MataKuliah {

}
