package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

/**
 * 
 * APS302 atau APS309 ?
 *
 */
@InfoMataKuliah(nama = "Dunia Digital Dan Sains", sks = 2)
public class APS309 extends MataKuliah {

}
