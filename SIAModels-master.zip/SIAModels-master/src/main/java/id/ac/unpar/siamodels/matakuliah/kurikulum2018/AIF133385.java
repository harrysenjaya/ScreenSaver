package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Praktika Pemrograman Berbasis Web", sks = 1)
public class AIF133385 extends MataKuliah {

}
