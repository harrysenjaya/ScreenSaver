package id.ac.unpar.siamodels.matakuliah;


import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Proses Produksi Pembentukan", sks = 2)
public class IIE207 extends MataKuliah {

}
