package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Interaksi Manusia Komputer", sks = 2)
public class AIF210 extends MataKuliah {

    
}
