package id.ac.unpar.siamodels.matakuliah;


import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Akuntansi Keuangan Dasar I", sks = 2)
public class EAA101 extends MataKuliah {

}