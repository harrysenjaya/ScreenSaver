package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Pengenalan Bidang Ilmu TIK", sks = 2)
public class AIF132281 extends MataKuliah {

}
