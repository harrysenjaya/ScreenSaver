package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Pencarian & Temu Kembali Informasi", sks = 2)
public class AIF461 extends MataKuliah {

}
