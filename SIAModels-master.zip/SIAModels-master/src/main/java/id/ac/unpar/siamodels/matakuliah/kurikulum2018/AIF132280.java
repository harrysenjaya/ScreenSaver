package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Praktika Interaksi Manusia Komputer", sks = 1)
public class AIF132280 extends MataKuliah {

}
