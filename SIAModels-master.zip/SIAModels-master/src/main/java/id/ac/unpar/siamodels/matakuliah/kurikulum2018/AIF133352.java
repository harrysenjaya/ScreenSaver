package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Jaringan Syaraf Tiruan", sks = 2)
public class AIF133352 extends MataKuliah {

}
