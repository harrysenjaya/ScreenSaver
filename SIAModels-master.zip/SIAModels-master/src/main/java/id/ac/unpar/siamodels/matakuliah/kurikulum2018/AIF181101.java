package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.matakuliah.interfaces.HasPraktikum;
import id.ac.unpar.siamodels.matakuliah.interfaces.HasResponsi;


@InfoMataKuliah(nama = "Pemodelan untuk Komputasi", sks = 3)
public class AIF181101 extends MataKuliah implements HasResponsi {

}
