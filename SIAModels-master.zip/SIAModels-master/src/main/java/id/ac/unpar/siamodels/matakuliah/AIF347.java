package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;

@InfoMataKuliah(nama = "E-Commerce", sks = 2)
public class AIF347 extends MataKuliah {

}
