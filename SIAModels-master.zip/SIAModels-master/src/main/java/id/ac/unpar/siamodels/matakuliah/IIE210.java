package id.ac.unpar.siamodels.matakuliah;


import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Perancangan Sistem Kerja Dan Ergonomi", sks = 2)
public class IIE210 extends MataKuliah {

}
