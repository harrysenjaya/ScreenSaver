package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Rekayasa Perangkat Lunak", sks = 4)
public class AIF132208 extends MataKuliah {

}
