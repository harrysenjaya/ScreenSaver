package id.ac.unpar.siamodels.matakuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Perilaku Keorganisasian", sks = 3)
public class ESM201 extends MataKuliah {
    
}