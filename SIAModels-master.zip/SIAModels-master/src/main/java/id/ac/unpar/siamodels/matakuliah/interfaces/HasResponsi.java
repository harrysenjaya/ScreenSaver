/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package id.ac.unpar.siamodels.matakuliah.interfaces;

/**
 *
 * @author FTIS\i13037
 */
public interface HasResponsi {

}
