package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Akuntansi Keuangan Dasar", sks = 4)
public class ESA101 extends MataKuliah {

}
