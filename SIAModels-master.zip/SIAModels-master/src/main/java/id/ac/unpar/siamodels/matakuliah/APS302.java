package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Dunia Digital Dan Sains", sks = 2)
public class APS302 extends MataKuliah {

}
