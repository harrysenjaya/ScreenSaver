package id.ac.unpar.siamodels.matakuliah;


import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Statistika Deskriptif", sks = 3)
public class IIE103 extends MataKuliah {

}