package id.ac.unpar.siamodels.matakuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Pembelajaran Mesin", sks = 3)
public class AIF335 extends MataKuliah {
    
}