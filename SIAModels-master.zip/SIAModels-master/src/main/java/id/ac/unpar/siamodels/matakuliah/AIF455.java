package id.ac.unpar.siamodels.matakuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;

@InfoMataKuliah(nama = "Sistem Pendukung Keputusan", sks = 3)
public class AIF455 extends MataKuliah {
    
}