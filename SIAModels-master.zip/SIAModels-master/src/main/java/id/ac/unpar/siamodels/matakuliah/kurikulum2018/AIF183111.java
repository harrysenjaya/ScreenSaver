package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.matakuliah.interfaces.*;


@InfoMataKuliah(nama = "Interaksi Manusia Komputer", sks = 3)
public class AIF183111 extends MataKuliah implements HasPraktikum{

}
