package id.ac.unpar.siamodels.matakuliah;

import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.InfoMataKuliah;

@InfoMataKuliah(nama = "Jaringan Syaraf Tiruan", sks = 2)
public class AIF352 extends MataKuliah {

}

