package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;
import id.ac.unpar.siamodels.matakuliah.interfaces.*;


@InfoMataKuliah(nama = "Topik Khusus Informatika 4", sks = 2)
public class AIF184120 extends MataKuliah implements HasPraktikum{

}
