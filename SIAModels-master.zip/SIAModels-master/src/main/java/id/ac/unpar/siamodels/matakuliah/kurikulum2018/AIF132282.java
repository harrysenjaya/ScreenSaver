package id.ac.unpar.siamodels.matakuliah.kurikulum2018;

import id.ac.unpar.siamodels.InfoMataKuliah;
import id.ac.unpar.siamodels.MataKuliah;


@InfoMataKuliah(nama = "Algoritma dan Struktur Data Lanjut", sks = 3)
public class AIF132282 extends MataKuliah {

}
